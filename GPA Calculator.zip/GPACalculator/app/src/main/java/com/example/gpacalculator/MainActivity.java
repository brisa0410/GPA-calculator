package com.example.gpacalculator;

import androidx.appcompat.app.AppCompatActivity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button compute;
    EditText sub1, sub2, sub3, sub4, sub5, total, avg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sub1 = findViewById(R.id.s1);
        sub2 = findViewById(R.id.s2);
        sub3 = findViewById(R.id.s3);
        sub4 = findViewById(R.id.s4);
        sub5 = findViewById(R.id.s5);
        total = findViewById(R.id.t);
        avg = findViewById(R.id.a);
        compute = findViewById(R.id.button);

        compute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isEmpty(sub1) || isEmpty(sub2) || isEmpty(sub3) || isEmpty(sub4) || isEmpty(sub5)) {
                    setFieldError("All fields must be filled");
                    return;
                }

                double n1 = Double.parseDouble(sub1.getText().toString());
                double n2 = Double.parseDouble(sub2.getText().toString());
                double n3 = Double.parseDouble(sub3.getText().toString());
                double n4 = Double.parseDouble(sub4.getText().toString());
                double n5 = Double.parseDouble(sub5.getText().toString());

                double totalMarks = n1 + n2 + n3 + n4 + n5;
                double average = totalMarks / 5;

                total.setText(String.valueOf(totalMarks));
                avg.setText(String.valueOf(average));

                // Set background color based on GPA calculation
                if (average < 60) {
                    avg.setBackgroundColor(getResources().getColor(R.color.red));
                } else if (average >= 60 && average <= 79) {
                    avg.setBackgroundColor(getResources().getColor(R.color.yellow));
                } else {
                    avg.setBackgroundColor(getResources().getColor(R.color.green));
                }

                // Change button text and clear fields
                compute.setText(getResources().getString(R.string.compute_button_text));
                clearFields();
            }
        });

        // Add an OnClickListener for sub1 EditText
        sub1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Change button text back to "Compute GPA"
                compute.setText(getResources().getString(R.string.compute_button_text));

                // Clear the background color of avg EditText
                avg.setBackgroundColor(Color.TRANSPARENT);
            }
        });
    }

    private boolean isEmpty(EditText editText) {
        return editText.getText().toString().trim().length() == 0;
    }

    private void setFieldError(String errorMessage) {
        // Display error message as a toast or in any desired way
        Toast.makeText(MainActivity.this, errorMessage, Toast.LENGTH_SHORT).show();
    }

    private void clearFields() {
        sub1.getText().clear();
        sub2.getText().clear();
        sub3.getText().clear();
        sub4.getText().clear();
        sub5.getText().clear();
    }
}
